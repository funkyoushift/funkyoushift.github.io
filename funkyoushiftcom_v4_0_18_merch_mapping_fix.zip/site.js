(function(){
  document.querySelectorAll('.navbar-toggle').forEach(function(button){
    button.addEventListener('click',function(){
      var nav=button.closest('.navbar'); var open=nav.classList.toggle('navbar--open'); button.setAttribute('aria-expanded',String(open));
    });
  });
  document.querySelectorAll('.twitch-loader').forEach(function(btn){
    btn.addEventListener('click',function(){
      var channel=btn.dataset.channel||'funkyoushift';
      var target=document.getElementById('twitch-frame')||btn.parentElement;
      target.innerHTML='<iframe title="FunkYouSHiFT Twitch stream" src="https://player.twitch.tv/?channel='+channel+'&parent=www.funkyoushift.com&parent=funkyoushift.com&muted=true" width="100%" height="420" allowfullscreen></iframe>';
      btn.remove();
    });
  });
  document.querySelectorAll('.planner-loader').forEach(function(btn){
    btn.addEventListener('click',function(){
      var target=document.getElementById('planner-frame');
      target.innerHTML='<iframe title="Maxroll Borderlands 4 planner" src="'+btn.dataset.src+'" width="100%" height="650" loading="lazy"></iframe><p class="fine-print">If the planner does not load here, open Maxroll directly.</p>';
      btn.remove();
    });
  });
  document.querySelectorAll('.video-loader').forEach(function(btn){
    btn.addEventListener('click',function(){
      var id=btn.dataset.video; var target=document.getElementById('video-frame'); if(!target){ target=document.createElement('div'); target.id='video-frame'; target.className='embed-frame'; btn.closest('section').appendChild(target); }
      target.innerHTML='<iframe title="Borderlands creator video" width="100%" height="420" src="https://www.youtube.com/embed/'+id+'?autoplay=1" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>';
    });
  });
  if ((window.GALLERY_ITEMS || window.FUNK_GALLERY_IMAGES) && document.getElementById('gallery-grid')) {
    var grid=document.getElementById('gallery-grid');
    (window.GALLERY_ITEMS || window.FUNK_GALLERY_IMAGES).forEach(function(item){
      var card=document.createElement('a'); card.className='gallery-card gallery-card--auto'; card.href=item.href||item.src; card.target='_blank'; card.rel='noopener';
      var img=document.createElement('img'); img.loading='lazy'; img.decoding='async'; img.src=item.src; img.alt=item.alt||'FunkYouSHiFT gallery image';
      img.onerror=function(){card.remove();};
      var title=document.createElement('strong'); title.textContent=item.title||'Stream Moment'; var label=document.createElement('span'); label.textContent=item.label||'Community / stream memory';
      card.appendChild(img); card.appendChild(title); card.appendChild(label); grid.appendChild(card);
    });
  }

  function loadExternalEmbed(btn){
    var target=document.getElementById(btn.dataset.embedTarget);
    if(!target){return;}
    var src=btn.dataset.embedSrc;
    var title=btn.dataset.embedTitle || 'Embedded community tool';
    target.classList.add('is-loaded');
    target.classList.remove('external-embed-frame--pending');
    target.innerHTML='<iframe title="'+title.replace(/"/g,'&quot;')+'" src="'+src+'" allow="clipboard-read; clipboard-write" referrerpolicy="no-referrer-when-downgrade"></iframe><p class="embed-fallback">If the tool does not load here, use the original-site button.</p>';
    btn.textContent=btn.dataset.loadedText || 'Reload embedded tool';
  }

  document.querySelectorAll('.external-embed-loader').forEach(function(btn){
    btn.addEventListener('click',function(){
      loadExternalEmbed(btn);
    });
    if(btn.dataset.autoEmbed === 'true'){
      var delay=parseInt(btn.dataset.autoEmbedDelay || '1800',10);
      var startAuto=function(){ window.setTimeout(function(){ loadExternalEmbed(btn); }, isNaN(delay) ? 1800 : delay); };
      if(document.readyState === 'complete'){ startAuto(); }
      else { window.addEventListener('load', startAuto, { once:true }); }
    }
  });
})();
