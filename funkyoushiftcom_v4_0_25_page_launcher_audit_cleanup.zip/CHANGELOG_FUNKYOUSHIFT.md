## v4.0.25 - Page launcher audit + mobile speed-bump cleanup
- Audited all public pages for redundant “What do you need?” / router panels before push.
- Kept the homepage launcher because it is the primary visitor menu.
- Removed the large Tools-page quick-pick panel so the GZO editor hub appears sooner, especially on mobile.
- Added a compact Tools shortcut bar for Editors, SDK Mods, Community Mods, Guides, More Links, and Discord Help.
- Replaced redundant Discord and Modding router card grids with slim shortcut bars.
- Fixed the Watch hero duplicate Discord button by making the primary CTA open Twitch.
- Fixed an obvious merch image mismatch where the black mug used the hat image in the merch feature/grid cards.
- Updated sitemap lastmod and cache version to 4.0.25.

## v4.0.24 - Franchise Tools + SDK mod hub
- Reframed `borderlands-resources.html` as a broader Borderlands franchise Tools hub instead of BL4-only resources.
- Updated SEO title, meta description, Open Graph copy, and JSON-LD to target save editors, item editors, SDK mods, mod databases, save locations, trainers, planners, and Discord help.
- Added a click-to-load BL-SDK Oak2 Mod Database embed panel after the auto-loading GZO editor hub.
- Added a placeholder Featured Community SDK Mods section for tomorrow's unlisted SDK mod files, with clear requirements for file, game, version, creator credit, permission, and install notes.
- Kept Azalea's Modding Center as a click-to-load guide/save-location embed.
- Added redirects for `/sdk-mods`, `/pc-mods`, `/borderlands-sdk-mods`, `/borderlands-save-editors`, `/borderlands-editor`, and `/item-editor`.
- Updated sitemap lastmod/priority and cache version to 4.0.24.

## v4.0.22 - Resources renamed to Tools for visitor clarity
- Kept `borderlands-resources.html` as the canonical/SEO URL but changed visible navigation from Resources to Tools.
- Added intuitive redirects for `/tools`, `/editors`, `/save-editors`, `/modding-tools`, and `/borderlands-tools`.
- Repositioned the Modding page as an SEO/plain-English guide that funnels visitors to the Tools page for embeds, editors, trainers, and planners.
- Updated cache references to 4.0.22.


## v4.0.19 - Giveaway Tile Exact Winner Photo
- Updated the homepage Giveaways card to use the exact winner/hat photo provided by the user.
- Updated cache references so the new giveaway tile is forced instead of older cached tile art.

# v4.0.18 - Merch link/image audit fix

- Rebuilt the merch card mapping based on the live Streamlabs audit.
- Changed merch cards so labels/images match the actual product destinations instead of the previous shifted order.
- Removed the struck/copyright-risk hat product from the visible lineup.
- Updated cache version to 4.0.18.

## v4.0.16 - Homepage tile cache-bust fix
- Renamed homepage tile image assets with a v16 suffix so browsers/CDN do not keep showing old cached button images.
- Updated CSS image references to the versioned tile files.
- Bumped page asset query versions to 4.0.16.
- Added an extra desktop hero safety rule so the title and art stay in separate columns.


## v4.0.15 - Hero readability fix
- Reduced the homepage title scale on desktop so “FUNKYOUSHIFT” no longer slides behind the hero image.
- Added layered/z-index protection and wider spacing between the title and hero art.
- Bumped cache version to 4.0.15.


## v3.3.7 Discord Landing Link Update
- Replaced expired Discord invite URL with the active Discord server landing page URL across all site CTAs, footers, schema sameAs entries, sticky mobile CTAs, and internal landing pages.
- Preserved third-party GenieBot/GZO Discord link separately.
- Bumped cache/version to 3.3.7.

# CHANGELOG_FUNKYOUSHIFT

## v2.0.0 - 2026-05-03
- Sitewide consistency pass across Home, Discord, Merch, Giveaway, Gallery, Donate.
- Standardized nav and footer links.
- Added page-specific SEO titles/descriptions/canonicals/Open Graph/Twitter metadata.
- Added page-specific JSON-LD schema graph to all major pages.
- Improved Discord page for clear join intent.
- Improved merch page with brand hook, product preview, and Streamlabs CTA.
- Improved giveaway page so giveaway is primary and donations are secondary.
- Improved donate page around Streamlabs/Throne support.
- Updated sitemap.xml, robots.txt, and llms.txt.


## v2.0.1 — Gallery Rebuild
- Rebuilt `gallery.html` from an empty tile loader into a curated visual gallery.
- Added featured brand art, stream/social assets, merch design cards, and responsive YouTube video highlight.
- Added gallery-specific CSS for image cards, responsive grids, and mobile display.
- Updated HTML cache-busting to `style.css?v=2.0.1` across pages.


## v2.0.2 — Merch Link Conversion + Natural Fixes
- Updated `merch.html` so every merch preview image/card is clickable.
- Added shopping-card labels under merch preview images to make the click action obvious.
- Linked merch feature artwork on the homepage to `merch.html`.
- Updated gallery merch artwork cards to point users to the Streamlabs merch store instead of raw image files.
- Added scoped CSS for clickable merch cards, hover/focus states, and mobile display.
- Updated version/cache busting from `2.0.1` to `2.0.2` across HTML/CSS.


## v2.1.0 — SEO traffic pages + resources hub — 2026-05-03
- Added `borderlands-modding.html` targeting Borderlands modding/modded item help.
- Added `borderlands-trading.html` targeting Borderlands trading/loot help.
- Added `borderlands-resources.html` linking Discord, Lootlemon, BL4Hunt, creator build video searches, and onsite traffic pages.
- Added `borderlands-build-videos.html` as a bridge page while build channels grow in Discord.
- Added homepage traffic-entry cards for modding, trading, and resources.
- Added resource links to nav/footer.
- Added internal link block to Discord page.
- Restored stream/offline/channel assets into Gallery so it is not only AI brand art.
- Updated `style.css` with v2.1.0 traffic/resource card styles.
- Updated `sitemap.xml`, `robots.txt`, `llms.txt`, project notes, and cache busting.

## v2.1.1 — Slideshow restore + image optimization — 2026-05-03
- Added the optimized `/slideshow/` asset folder back into the deployable site package.
- Added a visible Community Slideshow section to `gallery.html` using lazy-loaded optimized images.
- Optimized oversized site images for faster mobile loading and smaller deploy ZIP size.
- Converted opaque oversized brand art from heavy PNG files to compressed JPG references while preserving the transparent FU logo PNG.
- Added image dimensions/decoding attributes across local image tags to reduce layout shift and improve PageSpeed behavior.
- Updated cache busting from `style.css?v=2.1.7` to `style.css?v=2.1.7`.


## v2.1.2 - Page uniqueness and gallery cleanup
- Removed page-design assets, merch previews, and stream asset duplicates from the public Gallery page.
- Kept Gallery focused on community slideshow images and video highlight.
- Updated slideshow image CSS to preserve full images instead of cropping tall/narrow photos.
- Tightened homepage, Discord, merch, donate, giveaway, and Borderlands support page copy so each page has a clearer unique purpose.
- Updated CSS cache busting to style.css?v=2.1.7.


## v2.1.3 - Embedded resource upgrade
- Replaced description-only resource sections with embedded Discord and YouTube content.
- Added MentalMars Borderlands 4 Hub to the resources page and schema list.
- Added direct fallback links for external resources because some outside sites may block iframe previews.
- Updated build videos page with embedded creator videos plus a Discord build-showoff CTA.
- Updated cache busting to style.css?v=2.1.7.


## v2.1.4 - Resources cleanup
- Removed the old description card grid from borderlands-resources.html.
- Resources page now starts with embed-focused sections and simple action buttons only.
- Added anchors for build videos and resource site embeds.
- Updated cache busting to style.css?v=2.1.7.


## v2.1.6
- Removed the Discord preview from the Resources page so the page focuses only on tools, videos, and resource embeds.
- Tightened Resources page spacing for better mobile scrolling.
- Reduced external iframe heights and card padding so embeds feel less oversized.
- Updated cache busting to `style.css?v=2.1.7`.

## v2.1.6 - Sitemap optimization
- Rebuilt sitemap.xml with explicit <lastmod> values for all indexed pages.
- Confirmed sitemap URLs match actual HTML files in the deploy package.
- Adjusted priority/changefreq values to better match current site goals: home, Discord, merch, resources, content, then supporting pages.
- Updated CSS cache busting to style.css?v=2.1.7.



## v2.1.7 - Search Console SEO cleanup
- Switched canonicals, Open Graph URLs, sitemap, robots.txt, and schema URLs to the preferred non-www domain: https://www.funkyoushift.com/.
- Added dedicated video.html watch page with VideoObject schema for embedded Borderlands build videos.
- Updated navigation Watch links to point to the dedicated video page.
- Cleaned donate.html structured data and added valid BreadcrumbList + DonateAction schema to avoid itemListElement/name rich result errors.
- Updated sitemap.xml with video.html and refreshed lastmod values.
- Updated cache busting to style.css?v=2.1.7.
- Added _redirects helper for Cloudflare Pages-style redirect handling; Cloudflare dashboard rules should still be configured after deploy.

- Preferred canonical domain kept as https://www.funkyoushift.com/ to match the site CNAME and existing live routing.

## v2.1.8 - Homepage priority + SEO/AEO/PageSpeed polish
- Made Discord visually dominant on the homepage while keeping Watch as the secondary action; merch/socials remain available but no longer compete equally above the fold.
- Added a community proof strip and visible Quick Answers sections for AEO-style crawler/user clarity.
- Rebuilt JSON-LD across pages with consistent WebSite, Person, WebPage, BreadcrumbList, FAQPage, ItemList, Store, Event, DonateAction, and VideoObject where appropriate.
- Added lazy loading/referrer policies to embeds and preconnect hints for common external content providers.
- Created a WebP FU logo and updated logo references for smaller downloads.
- Optimized JPG assets and refreshed image width/height attributes to reduce file weight and layout shift.
- Rebuilt sitemap.xml with video sitemap data and current priority order: Home, Discord, Watch, Resources, Merch, supporting Borderlands pages, Giveaway, Gallery, Donate.
- Updated cache busting to `style.css?v=2.1.8` and body version to `2.1.8`.


## v2.1.9 - Mobile UX + speed polish
- Compared uploaded friend-optimized index.html against the current package. Kept the current v2.1.8 SEO/AEO/schema/canonical structure and used the useful mobile menu idea globally.
- Added a mobile-only collapsed navigation button to every HTML page so phones no longer open with eight full orange nav buttons.
- Tightened mobile hero, card, section, gallery, resource, footer, and embed spacing.
- Preserved full gallery/slideshow image display with object-fit: contain so tall/narrow images are not cropped.
- Fixed a duplicate nested @media line in style.css.
- Updated cache busting to style.css?v=2.1.9 and body data-version to 2.1.9.
- Updated sitemap lastmod values.

## v3.0.0 - Mobile homepage hard optimize - 2026-05-03
- Created `PROJECT_REFERENCE_FUNKYOUSHIFT.md` as the readable consolidated source of rules, goals, page notes, and version history.
- Removed homepage reliance on the external Google Font request to reduce render-blocking work.
- Replaced the heavy homepage Twitch iframe with a lightweight watch card linking to `video.html` and Twitch.
- Added smaller WebP image derivatives for homepage hero, watch, and merch artwork.
- Updated homepage hero/merch images to use smaller responsive WebP assets.
- Added mobile-first v3 CSS overrides for cleaner above-the-fold layout, tighter sections, better tap targets, and less mobile clutter.
- Updated cache busting and body data versions to `3.0.0`.


## v3.0.1 - Human copy/resource embed cleanup - 2026-05-03
- Confirmed the Twitch embed was intentionally removed from the homepage for mobile speed; kept Twitch available through the Watch page and direct Twitch buttons.
- Rewrote robotic/AEO-sounding visitor copy on the homepage, Watch page, Resources page, and selected Quick Answer sections into a more natural FunkYouSHiFT voice.
- Removed broken external site iframes from the Resources page, including Lootlemon, and replaced them with clean direct-link resource cards.
- Kept YouTube embeds because those render correctly and are appropriate for watch/build video content.
- Updated cache busting and body data version to `3.0.1`.

## v3.1.0 - Homepage human rewrite + lazy Twitch - 2026-05-03
- Rewrote the homepage visible copy in a more natural FunkYouSHiFT voice instead of generic landing-page/AEO phrasing.
- Added the Twitch experience back to the homepage as a click-to-load player so the heavy Twitch iframe does not load during initial page render.
- Kept direct Watch page and Twitch links below the lazy player.
- Updated homepage FAQ text and matching FAQPage schema.
- Updated CSS cache busting and body data version to `3.1.0`.


## v3.1.0 - Full human tone + SEO pass - 2026-05-03
- Actually edited the site files instead of providing copy/paste instructions.
- Reworked visible copy across Home, Discord, Watch, Merch, Donate, Giveaway, Gallery, Resources, Modding, Trading, and Build Videos.
- Kept the tone direct, creator/community-focused, and less corporate while preserving search-friendly Borderlands terms.
- Updated page titles and meta descriptions for stronger click-through language.
- Kept the homepage click-to-load Twitch player so Twitch is present without loading during initial mobile render.
- Kept Lootlemon as a direct link because it blocks iframe embedding.
- Bumped cache busting/body versions to `3.1.0`.

## v3.2.0 - Phase 2 growth build - 2026-05-03
- Added dedicated SEO/AEO pages for the current Search Console opportunity: `borderlands-discord.html`, `borderlands-modded-weapons.html`, and `borderlands-builds.html`.
- Updated homepage title/description and added a visible Borderlands Discord entry section targeting Borderlands Discord, BL3/BL4 Discord, modded weapons, and builds.
- Kept canonical strategy consistent: preferred domain is `https://www.funkyoushift.com/`; homepage canonical is `/`; internal content pages use `.html` canonicals.
- Updated page titles and meta descriptions across all pages to use a consistent `| FunkYouSHiFT` style while preserving CTR-focused search language.
- Updated sitemap.xml, llms.txt, redirects, internal links, schema WebPage metadata, cache busting, and body version to `3.2.0`.
- Local internal link audit passed after changes; no missing local `.html`, image, CSS, or slideshow targets found.

## v3.2.1 — Gallery Auto-Fix System
- Rebuilt the gallery slideshow section so it renders from `gallery-manifest.js` instead of hardcoded repeated slide cards.
- Generated the manifest from the actual `/slideshow/` files included in the ZIP.
- Added image error handling to remove missing/broken gallery cards from the page automatically.
- Added a no-JavaScript fallback gallery subset.
- Polished homepage About spacing.
- Updated CSS cache busting/body versions to `3.2.1`.


## v3.2.3 - Readability / anti-blur polish - 2026-05-03
- Fixed blurry-looking body text by using a normal sans-serif font for paragraphs and small copy.
- Preserved the Bangers brand font for headings, buttons, nav, and card titles.
- Removed paragraph text shadows and refreshed cache busting to 3.2.3.


## v3.2.3 - Final Mobile Polish Pass
- Fixed homepage hero layout on mobile so the text no longer squeezes into a skinny column.
- Forced true mobile stack: headline, image, text, buttons, proof badges.
- Tightened mobile button widths, badge layout, section width, and overflow handling.

- Mobile hero polish: brand image now sits between headline and copy on phones; headline sizing capped to prevent horizontal overflow.

## v3.3.0 - Modding authority build - 2026-05-04
- Rebuilt `borderlands-modding.html` into the primary authority page for Borderlands modding, modded weapons, BL3/BL4 help, trusted resources, and Discord conversion.
- Updated title/meta/OG/schema with direct `Borderlands modding`, `modded weapons`, `BL3`, `BL4`, `Discord help`, and resource language so Google has a stronger snippet source than generic About copy.
- Added Article + FAQPage schema to the modding page and refreshed FAQ questions around modding, modded weapons, downloads, and BL3/BL4 help.
- Updated homepage title/description and the top search-entry section to route modding searches directly into the modding guide.
- Updated Borderlands Discord and Modded Weapons page metadata to reinforce modding/trading/gear search intent.
- Updated sitemap priority/lastmod, llms.txt, cache busting, and body version to v3.3.0.


## v3.3.1 - Internal linking system - 2026-05-04
- Added global nav links for Modding, Weapons, and Builds so the new SEO pages are not orphaned behind Resources only.
- Added footer links to Borderlands Discord, Modding Guide, Modded Weapons, Builds, and Resources across every HTML page.
- Added a reusable “More Borderlands help” internal-link cluster to every page so authority flows between the modding, Discord, modded weapons, and builds pages.
- Rebuilt sitemap.xml with the modding authority page, Discord page, modded weapons page, and builds page prioritized before lower-value support pages.
- Confirmed canonical strategy remains consistent: homepage canonical is https://www.funkyoushift.com/ and content pages use https://www.funkyoushift.com/page-name.html.
- Updated cache busting/body version to v3.3.1.


## v3.3.2 Resource Expansion
- Added requested Borderlands mod databases, editors, trainers, GenieBot tutorial/community link, Maxroll planner, and build creator resources.
- Added safety wording around third-party trainers/executable downloads and clarified third-party ownership.
- Updated Resources and Builds metadata/schema while keeping canonical `.html` structure and internal linking intact.


## v3.3.3 Creator Integration Patch
- Converted YouTube creator videos to click-to-load embeds so YouTube does not load on initial page load.
- Converted Maxroll BL4 planner to click-to-load iframe attempt with direct fallback.
- Expanded creator SEO/resource mentions for Moxsy, Ki11er Six, Joltzdude139, LazyData, Dantics, and RestAssured.
- Kept third-party creator/resource language clear: links are references, not FunkYouSHiFT-owned content.


## v3.3.4 - Homepage Compression Without Losing SEO
- Shortened the homepage mobile flow by replacing duplicate long sections with focused routing cards.
- Kept Borderlands modding, modded weapons, Discord, builds, and resources language near the top for CTR/SEO.
- Moved the homepage toward a hub model: Home routes traffic, Modding explains, Resources holds tools, Discord converts.
- Kept lazy Twitch click-to-load behavior.
- Kept global footer/internal links to the new SEO pages for crawl flow.


## v3.3.7 Landing Router System
- Added fast-decision router sections to Borderlands landing pages, Resources, Watch, and Discord pages.
- Added mobile-only sticky Discord CTA to reduce friction for search visitors.
- Kept Resources as the toolbox and Modding as the SEO landing page.
- Bumped cache/version to 3.3.7.


## v3.3.7 - Safe direct download system
- Added `downloads/borderlands-4-trainer.html` as a noindex/nofollow landing page for the hosted Borderlands 4 trainer EXE.
- Resources page now routes the BL4 trainer through the safe download page instead of treating the EXE like a normal SEO resource.
- Added safety language for third-party executables and kept the download page out of the sitemap.
- Added robots directives for `.exe` crawling while keeping main SEO pages clean.

## v3.3.8 - Visual readability polish
- Replaced the hard-to-read display font on nav buttons, page titles, headings, card labels, and large CTA buttons with a crisp heavy system font.
- Removed heavy text shadows/outlined heading effects that made orange and white heading text look blurry.
- Kept the orange/black FunkYouSHiFT styling through color, weight, layout, and gradients instead of relying on blurry display text.
- Updated cache busting/body version to 3.3.8.


## v3.3.9 - Header/Footer + Readability Verification
- Standardized header/nav and footer links across all HTML pages, including the safe download page.
- Bumped all stylesheet cache versions and body data-version values to 3.3.9.
- Applied final global readability rules to nav buttons, titles, section headers, and CTA buttons.
- Verified internal links/assets after update.


## v3.3.10 - Desktop Performance Recovery
- Added homepage LCP image preload and fetch priority.
- Removed remaining blurry paint-heavy text effects from nav/buttons/headers.
- Tightened desktop nav/button rendering without changing header/footer link structure.
- Bumped cache/version to 3.3.10.


## v4.0.0 - Clean Structure Rebuild
- Consolidated scattered SEO pages into a cleaner user-first structure.
- Home is now a short router instead of a long content stack.
- Modding is the main authority landing page for modding, modded gear, and tools.
- Builds owns planner/creator content.
- Resources is the toolbox only.
- Discord owns community/trading/help conversion.
- Redirected duplicate pages instead of keeping duplicate content in sitemap.
- Rebuilt typography/CSS for readability and mobile flow.


## v4.0.1 - Resources clarity rebuild
- Rebuilt Resources as one clean toolbox page instead of a flat link dump.
- Grouped BL4 tools, mod databases/references, original trainer pages, databases/guides, and creator links.
- Added creator/tool credit language and kept third-party download safety wording.
- Kept one resources page instead of splitting by game title.


## v4.0.2 - human-facing copy audit
- Rechecked visible site copy for placeholder/dev-note language.
- Rewrote resources, landing pages, redirect stubs, footer notes, and download page wording to read for players.
- Bumped cache/version to 4.0.2.


## 4.0.3 - Media page restoration
- Restored live gallery rendering from gallery-manifest.js.
- Restored merch preview cards and Streamlabs CTAs.
- Restored richer Watch page with lazy Twitch loader.
- Restored creator thumbnail cards on Builds while keeping v4 clean structure.
- Audited visible copy for dev-note language and kept giveaway hidden from nav for now.


## v4.0.4 - Restore Throne wishlist embed
- Restored the embedded Throne wishlist on the Support/Donate page.
- Kept direct Throne fallback button for browsers that block embeds.
- Bumped cache/version to 4.0.4.


## v4.0.5
- Replaced FunkYouSHiFT-owned images on third-party creator cards with YouTube video thumbnails from the creators' own content.
- Kept creator links external and nofollow.
- Bumped cache/version to 4.0.5.


## 4.0.6 - Hunt / Charity System
- Added a compact Hunt / charity event panel to the homepage.
- Added a fuller Hunt / St. Jude PLAY LIVE explanation section to the Support page.
- Linked to the official St. Jude PLAY LIVE information and campaign hub.
- Kept fundraiser details routed through Discord until a specific fundraiser URL is provided.
- Bumped cache/version to 4.0.6.


## v4.0.7 - Hosted trainer path verification
- Confirmed `downloads/Borderlands 4.exe` is included in the site package.
- Updated the safe download page button to `/downloads/Borderlands%204.exe`.
- Kept the download page noindex/nofollow and out of sitemap.
- Updated robots.txt to block `.exe` crawling while allowing the HTML safety page to be crawled for noindex.

## v4.0.8 - Resources page simplified
- Reworked `borderlands-resources.html` into a large-button resource hub for Twitch-viewer-friendly navigation.
- Added click-to-load embedded GZO Editor Hub (`https://save-editor.be/GZO/`) with original-site fallback.
- Added click-to-load embedded Azalea's Modding Center (`https://save-editor.be/GZO/AMC.html`) with original-site fallback.
- Moved long resource lists into collapsible drawers to reduce visible text clutter while keeping the content available.
- Added responsive CSS for large visual buttons, embed panels, and simplified resource drawers.
- Added generic `.external-embed-loader` support in `site.js`.


## v4.0.9 - Visual merch/home overhaul
- Added new Team FunkYouSHiFT artwork with the updated member lineup.
- Replaced old Team artwork references with the new brand art for OG/social previews and hero imagery.
- Rebuilt the homepage into a short, button-first launcher for Twitch viewers.
- Rebuilt the merch page as a visual storefront with uploaded mockups and Streamlabs product links.
- Added new art previews to the gallery.
- Continued the reduced-copy, big-button, imagery-heavy design direction.


## v4.0.10 - Delayed GZO auto-embed
- Updated the Resources page so the main GZO Editor Hub automatically loads after a short delay instead of requiring the visitor to press a button.
- Kept the manual reload button and original-site fallback button for browsers that block embeds.
- Left Azalea's Modding Center as click-to-load so the page does not load multiple external tools at once.


## v4.0.11 - Live preview cleanup
- Removed duplicate-feeling homepage CTAs from the hero and converted the extra visual strip into non-link imagery.
- Updated homepage button backgrounds so each action has a more distinct visual story.
- Removed visible “auto-loads after page load” wording from the Resources panel.
- Made the GZO auto-embed more reliable by loading after the window load event and removing lazy-loading from the inserted iframe.
- Simplified the Builds page so the top area no longer repeats the lower planner/video/help sections.
- Bumped CSS and JS cache versions to 4.0.11.


## v4.0.13 - Homepage image storytelling pass
- Added new user-provided Discord, Twitch/YouTube, stream screenshot, real hat, and community art assets.
- Replaced generic homepage button backgrounds with purpose-built visual tiles for Discord, modded gear, save editors, watch, merch, giveaways, character builds, and gallery.
- Corrected Builds visual direction to character builds / skill trees / loadouts instead of PC builds.
- Expanded the homepage visual strip with real community/stream/hat imagery for more variety.
- Kept the current color scheme while making button imagery tell the story faster for Twitch viewers.


## v4.0.13 - Image optimization cleanup
- Removed heavy duplicate PNG/MP4 slideshow originals that were not referenced by the live pages.
- Swapped gallery full-size art links to optimized WebP assets.
- Kept the direct trainer executable in downloads, but reduced the package size so the ZIP stays under GitHub Desktop’s 100MB warning.
- Note: deploy by extracting the ZIP and committing the site files, not by committing the ZIP itself.

## v4.0.14 - Homepage image mapping and gallery cleanup
- Removed the four-image story strip from the homepage so the homepage stays focused as a quick launcher.
- Moved extra real/community images into the Gallery page.
- Updated the Get Modded Gear button image to use the in-game legendary loot screenshot.
- Updated the Giveaways button image to use the real smiling giveaway winner screenshot.
- Kept Builds on the stylized skill-tree tile for now until a real Borderlands skill tree screenshot is provided.
- Added optimized gallery WebP versions of the new community images.


## v4.0.17 - Hero + tile deploy safety fix
- Added decisive homepage hero sizing so the FUNKYOUSHIFT title cannot slide behind the hero image on desktop.
- Added v17 cache-busted homepage tile image filenames.
- Forced homepage tile background rules to the intended images to avoid stale/older rules winning.


## v4.0.20 - Giveaway tile position fix
- Re-cropped the Giveaways homepage tile from the real winner/hat photo so the hat logo and face sit lower and more centered inside the card.
- Updated homepage asset cache references to 4.0.20.


## v4.0.21 - Resources embed space cleanup
- Widened the Resources page on desktop so the embedded GZO editor hub uses more available screen space.
- Reduced padding around resource embed panels and increased iframe height for better visibility.
- Bumped resource page cache references to 4.0.21.
