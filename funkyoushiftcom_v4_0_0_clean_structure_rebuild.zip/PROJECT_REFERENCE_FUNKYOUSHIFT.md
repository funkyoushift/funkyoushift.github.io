# FunkYouSHiFT Project Reference - v4.0.0

## Current Site Strategy
The site is now organized for humans first while keeping SEO signals intact.

### Core pages
- `index.html`: short homepage router.
- `borderlands-modding.html`: main SEO authority page for Borderlands modding, modded weapons, save editing, trainers, tools, and Discord help.
- `borderlands-builds.html`: builds, Maxroll planner, creator resources, and Discord feedback.
- `borderlands-resources.html`: toolbox only: mod databases, editors, trainers, GenieBot, Maxroll, creators, Lootlemon, MentalMars, BL4Hunt.
- `borderlands-discord.html`: Discord landing page for trading, modded gear help, giveaways, and active community.

### Merged pages
- `borderlands-modded-weapons.html` → `borderlands-modding.html`
- `borderlands-trading.html` → `borderlands-discord.html`
- `borderlands-build-videos.html` → `borderlands-builds.html`
- `discord.html` → `borderlands-discord.html`

These are redirect/noindex compatibility pages and are not in the sitemap.

### SEO notes
- Sitemap includes only core pages and brand pages.
- Download page and `.exe` are excluded from indexing.
- Canonicals use `https://www.funkyoushift.com/` and `.html` content pages.
- Discord link is the server landing page: https://discord.com/servers/funk-s-borderlands-trading-hub-997021744764289084

### UX rules
- No placeholder phrases like “for SEO.”
- Homepage stays short on mobile.
- Resources should remain a toolbox, not another explanation page.
- Modding explains. Resources links. Discord converts. Builds helps.
